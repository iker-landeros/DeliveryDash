import "./Styles/Fuente.css";
import Views from "./Components/Views";
const App = () => {
  return (
    <Views/>
  )
}

export default App;